package web.howmany.upso;

import lombok.Data;

@Data
public class SmallcitysVO {

	private int cno;
	private String name;
	private int city_value; 
}
