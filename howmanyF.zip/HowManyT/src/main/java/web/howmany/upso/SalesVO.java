package web.howmany.upso;

import lombok.Data;

@Data
public class SalesVO {
	private int ssno;
	private int city_value;
	private int upjong_value;
	private int cno;
	private int uno;
	private int sales1;
	private int unitcost1;
	private int sales2;
	private int unitcost2;
}
