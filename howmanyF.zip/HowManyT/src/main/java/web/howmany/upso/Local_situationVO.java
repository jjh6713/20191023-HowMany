package web.howmany.upso;

import lombok.Data;

@Data
public class Local_situationVO {

	private int lno;
	private int city_value;
	private int upjong_value;
	private int cno;
	private int uno;
	private int t_household;
	private int t_population;
	private int landmark;
	private int standard_mp;
	private int num_upso;
	private int u_household;
	private int u_facility;
	private int k_facility;
}
