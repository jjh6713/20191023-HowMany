package web.howmany.upso;

import lombok.Data;

@Data
public class BigcitysVO {

	private int city_value;
	private String name;
}
