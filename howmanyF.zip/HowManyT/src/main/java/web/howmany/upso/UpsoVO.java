package web.howmany.upso;

import lombok.Data;

@Data
public class UpsoVO {
	private int upno;
	private int city_value;
	private int upjong_value;
	private int cno;
	private int uno;
	private int half1;
	private int half2;
	private String percent;
}
