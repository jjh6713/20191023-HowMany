package web.howmany.upso;

import lombok.Data;

@Data
public class SmallupjongsVO {
	private int uno;
	private String name;
	private int upjong_value;
}
