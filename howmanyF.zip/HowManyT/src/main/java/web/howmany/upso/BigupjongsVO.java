package web.howmany.upso;

import lombok.Data;

@Data
public class BigupjongsVO {

	private int upjong_value;
	private String name; 
}
