package web.howmany.domain;

import lombok.Data;

@Data
public class Population_dataVO {

	private String camera_id;
	private String population_count; 
	private String population_date;
}
