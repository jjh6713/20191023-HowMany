package web.howmany.domain;

import lombok.Data;

@Data
public class Camera_statusVO {

	private String camera_id;
	private String camera_name; 
	private String camera_position01;
	private String camera_position02; 
}
