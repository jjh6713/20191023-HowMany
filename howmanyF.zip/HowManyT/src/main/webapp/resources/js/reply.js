var replyService = (function(){
	
	//insert ajax
	function insert(reply, callback){

		$.ajax({
			type:"post",
			url:'/reply/insert',
			data:JSON.stringify(reply),
			contentType:"application/json; charset=utf-8",
			success:function(result,status,xhr){
				if(callback){
					callback(result);
				}
			}
			
		})
	}
	

	//list ajax
	function list(param, callback, error){
		var board_no = param.board_no;
		var page = param.page || 1;
		
		$.getJSON("/reply/pages/"+board_no+"/"+page+".json",
			function(data){
				if(callback){
					callback(data.reply_count,data.reply_list);
				}
			}).fail(function(xhr, status, err){
				if(error){
					error();
				}
			});
	}

	//delete ajax
	function del(reply_no, callback, error){
		$.ajax({
			type:"delete",
			url:'/reply/'+reply_no,
			success:function(result,status,xhr){
				if(callback){
					callback(result);
				}
			}
		})
	}

	//update ajax
	function update(reply, callback){
		$.ajax({
			type:"put",
			url:'/reply/'+reply.reply_no,
			data:JSON.stringify(reply),
			contentType:"application/json; charset=utf-8",
			success:function(result,status,xhr){
				if(callback){
					callback(result);
				}
			}
		})
	}

	//view ajax
	function view(reply_no, callback){
		$.get("/reply/"+reply_no+".json",function(result){
			if(callback){
				callback(result);
			}
		})
	}
	
	//시간표시
	function displayTime(timeValue){
		var today = new Date();
		var gap = today.getTime() - timeValue;
		var dateObj = new Date(timeValue);
		var str = "";
		
		if(gap < (1000* 60 * 60 *24)){
			var hh = dateObj.getHours();
			var mi = dateObj.getMinutes();
			var ss = dateObj.getSeconds();
			
			return [ (hh>9?'':'0')+hh,':',(mi>9?'':'0')+mi,':',(ss>9?'':'0')+ss].join('');
		}else{
			var yy = dateObj.getFullYear();
			var mm = dateObj.getMonth() + 1;
			var dd = dateObj.getDate();
			
			return [ yy, '/', (mm>9?'':'0')+mm,'/',(dd>9?'':'0')+dd].join('');
		}
	}
	
	return{
		insert:insert,
		list:list,
		del:del,
		update:update,
		view:view,
		displayTime:displayTime
	}
})();